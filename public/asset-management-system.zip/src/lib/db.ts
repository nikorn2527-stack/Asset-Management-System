import { PrismaClient } from "@prisma/client";
import { PrismaLibSQL } from "@prisma/adapter-libsql";
import { createClient } from "@libsql/client";

/**
 * Dual-mode Prisma client — works for both Railway (SQLite) and Vercel (Turso/libsql).
 *
 * Runtime detection based on DATABASE_URL:
 *   - Starts with "libsql:" → uses @prisma/adapter-libsql (Vercel + Turso)
 *   - Anything else       → plain PrismaClient (Railway / local SQLite)
 *
 * No top-level await. All static imports — Next.js bundles them at build time;
 * the libsql client is only instantiated when DATABASE_URL starts with "libsql:".
 */

const databaseUrl = process.env.DATABASE_URL ?? "file:./db/custom.db";

const prisma = databaseUrl.startsWith("libsql:")
  ? new PrismaClient({
      adapter: new PrismaLibSQL(
        createClient({
          url: databaseUrl,
          authToken: process.env.DATABASE_AUTH_TOKEN,
        })
      ),
    } as never)
  : new PrismaClient();

// Singleton pattern to prevent multiple instances in development (HMR)
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const db: PrismaClient =
  globalForPrisma.prisma ?? prisma;

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = db;
}